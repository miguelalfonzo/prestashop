<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Bloc sélecteur de langue';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Ajoute un bloc permettant à vos clients de sélectionner la langue de votre boutique.';


return $_MODULE;
