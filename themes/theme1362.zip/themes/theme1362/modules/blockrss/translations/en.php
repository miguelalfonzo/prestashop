<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockrss}prestashop>blockrss_2516c13a12d3dbaf4efa88d9fce2e7da'] = 'RSS feed block';
$_MODULE['<{blockrss}prestashop>blockrss_4bb9f05422c5afbb84ed1eeb39beb8c6'] = 'Adds a block displaying a RSS feed.';
$_MODULE['<{blockrss}prestashop>blockrss_9680162225162baf2a085dfdc2814deb'] = 'RSS feed';
$_MODULE['<{blockrss}prestashop>blockrss_6706b6d8ba45cc4f0eda0506ba1dc3c8'] = 'Invalid feed URL';
$_MODULE['<{blockrss}prestashop>blockrss_36ed65ce17306e812fd68d9f634c0c57'] = 'Invalid title';
$_MODULE['<{blockrss}prestashop>blockrss_1b3d34e25aef32a3c8daddfff856577f'] = 'Invalid number of feeds';
$_MODULE['<{blockrss}prestashop>blockrss_549a15a569b4e5e250275db17712cd91'] = 'You have selected a feed URL from your own website. Please choose another URL.';
$_MODULE['<{blockrss}prestashop>blockrss_bef637cd0e222a8b56676cb64ce75258'] = 'Feed is unreachable, check your URL';
$_MODULE['<{blockrss}prestashop>blockrss_1844ef1bfaa030dc8423c4645a43525c'] = 'Invalid feed:';
$_MODULE['<{blockrss}prestashop>blockrss_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{blockrss}prestashop>blockrss_0a1c629f0e86804a9e165f4b1ee399b7'] = 'Error: invalid RSS feed in "blockrss" module: %s';
$_MODULE['<{blockrss}prestashop>blockrss_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockrss}prestashop>blockrss_b22c8f9ad7db023c548c3b8e846cb169'] = 'Block title';
$_MODULE['<{blockrss}prestashop>blockrss_5a33009bfebd22448e4265f65f8a7d98'] = 'Create a title for the block (default: \'RSS feed\').';
$_MODULE['<{blockrss}prestashop>blockrss_402d00ca8e4f0fff26fc24ee9ab8e82b'] = 'Add a feed URL';
$_MODULE['<{blockrss}prestashop>blockrss_3117d1276345461366a62c6950c186ed'] = 'Add the URL of the feed you want to use (sample: http://news.google.com/?output=rss).';
$_MODULE['<{blockrss}prestashop>blockrss_ff9aa540e20285875ac8b190a3cb7ccf'] = 'Number of threads displayed';
$_MODULE['<{blockrss}prestashop>blockrss_0b4c4685f03f258492af3705a03b619b'] = 'Number of threads displayed in the block (default value: 5).';
$_MODULE['<{blockrss}prestashop>blockrss_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockrss}prestashop>blockrss_10fd25dcd3353c0ba3731d4a23657f2e'] = 'No RSS feed added';


return $_MODULE;
