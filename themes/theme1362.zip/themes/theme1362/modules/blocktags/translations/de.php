<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Block Tags';
$_MODULE['<{blocktags}prestashop>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'Fügt einen Block mit einer Tag-Cloud hinzu';
$_MODULE['<{blocktags}prestashop>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'Sie müssen das Feld "Angezeigte Tags" ausfüllen.';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Ungültige Anzahl';
$_MODULE['<{blocktags}prestashop>blocktags_fb3855930920fd1ef34c4904ef230802'] = 'Bitte füllen Sie das Feld "Tag-Ebenen" aus.';
$_MODULE['<{blocktags}prestashop>blocktags_feb6da9d1dab0d22293d1da205fa1bb2'] = 'Ungültiger Wert für "Tag-Ebenen". Geben Sie eine positive Ganzzahl ein.';
$_MODULE['<{blocktags}prestashop>blocktags_08d5df9c340804cbdd62c0afc6afa784'] = 'Füllen Sie bitte  das Feld "Zufallsgenerator" aus.';
$_MODULE['<{blocktags}prestashop>blocktags_5c35c840e2d37e5cb3b6e1cf8aa78880'] = 'Ungültiger Wert für "Zufallsgenerator". Zulässig ist nur 0 oder 1.';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocktags}prestashop>blocktags_726cefc6088fc537bc5b18f333357724'] = 'Angezeigte Tags';
$_MODULE['<{blocktags}prestashop>blocktags_34a51d24608287f9b34807c3004b39d9'] = 'Legen Sie die Anzahl der Tags in diesem Block fest. (Standard: 10)';
$_MODULE['<{blocktags}prestashop>blocktags_ed7a7c842913f44b32b0f06d5a369dcf'] = 'Tag-Ebenen';
$_MODULE['<{blocktags}prestashop>blocktags_d088d9f9a8634d69a2aa0b11883fb6b1'] = 'Legen Sie die Anzahl der verschiedenen Tag-Ebenen fest. (Standard: 3)';
$_MODULE['<{blocktags}prestashop>blocktags_ac5bf3b321fa29adf8af5c825d670e76'] = 'Zufällige Anordnung';
$_MODULE['<{blocktags}prestashop>blocktags_d4a9f41f7f8d2a65cda97d8b5eb0c9d5'] = 'Wenn aktiviert, werden die Tags in zufälliger Reihenfolge angezeigt.  Standardmäßig ist diese Funktion deaktiviert, und die meistgewählten Tags werden zuerst angezeigt.';
$_MODULE['<{blocktags}prestashop>blocktags_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blocktags}prestashop>blocktags_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Mehr darüber';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'noch keine Tags angegeben';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'noch keine Tags angegeben';


return $_MODULE;
