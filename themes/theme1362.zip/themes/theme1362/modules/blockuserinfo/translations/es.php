<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Bloque de información de usuario';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Añadir un bloque que muestre información sobre el cliente.';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_0c3bf3014aafb90201805e45b5e62881'] = 'Ver mi carrito de compra';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Carrito:';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_deb10517653c255364175796ace3553f'] = 'producto';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'Productos';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = 'vacío';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_2cbfb6731610056e1d0aaacde07096c1'] = 'Ver mi cuenta de cliente';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Su cuenta';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Bienvenido';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Cerrer sesión';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_c87aacf5673fada1108c9f809d354311'] = 'Cerrar sesión';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_d4151a9a3959bdd43690735737034f27'] = 'Entrar a tu cuenta de cliente';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Iniciar sesión';
$_MODULE['<{blockuserinfo}prestashop>nav_2cbfb6731610056e1d0aaacde07096c1'] = 'Ver mi cuenta de cliente';
$_MODULE['<{blockuserinfo}prestashop>nav_4b877ba8588b19f1b278510bf2b57ebb'] = 'Cerrer sesión';
$_MODULE['<{blockuserinfo}prestashop>nav_c87aacf5673fada1108c9f809d354311'] = 'Cerrar sesión';
$_MODULE['<{blockuserinfo}prestashop>nav_d4151a9a3959bdd43690735737034f27'] = 'Entrar a tu cuenta de cliente';
$_MODULE['<{blockuserinfo}prestashop>nav_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Iniciar sesión';


return $_MODULE;
