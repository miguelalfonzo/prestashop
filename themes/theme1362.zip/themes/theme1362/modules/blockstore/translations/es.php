<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockstore}prestashop>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Bloque tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'Muestra un enlace a la imagen característica de localización de tiendas de PrestaShop.';
$_MODULE['<{blockstore}prestashop>blockstore_b786bfc116ecf9a6d47ce1114ca6abb7'] = 'Este módulo requiere estar enganchado a una columna y su tema no tiene implementada ninguna.';
$_MODULE['<{blockstore}prestashop>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'imagen no válida.';
$_MODULE['<{blockstore}prestashop>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'Se ha producido un error durante el envío.';
$_MODULE['<{blockstore}prestashop>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados';
$_MODULE['<{blockstore}prestashop>blockstore_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockstore}prestashop>blockstore_4d100d8b1b9bcb5a376f78365340cdbe'] = 'Imagen para el bloque Localizacion de la Tienda';
$_MODULE['<{blockstore}prestashop>blockstore_a34202cc413553fe0fe2d46f706db435'] = 'Texto para el bloque Localización de la Tienda';
$_MODULE['<{blockstore}prestashop>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockstore}prestashop>blockstore_8c0caec5616160618b362bcd4427d97b'] = '¡Nuestra(s) tienda(s)!';
$_MODULE['<{blockstore}prestashop>blockstore_28fe12f949fd191685071517628df9b3'] = 'Descubra nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Descubra nuestras tiendas';


return $_MODULE;
